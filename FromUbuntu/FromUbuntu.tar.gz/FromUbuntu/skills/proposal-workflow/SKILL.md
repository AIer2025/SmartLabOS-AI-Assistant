---
name: "proposal-workflow"
description: "百泉聚兴 SmartLabOS 提案全流程工作流管理器。当用户说'新建提案'、'提案流程'、'开始提案'时触发。管理提案从创建到发布的五个阶段，追踪每个阶段的状态，确保流程有序推进。"
version: "1.0.0"
tags: ["smartlabos", "workflow", "百泉聚兴", "提案"]
tools: ["read", "write"]
---

# SmartLabOS 提案工作流管理器

## 目的
作为主控编排器，管理提案从创建到发布的完整五阶段工作流。
确保每个阶段按顺序执行，追踪状态，阻止跳过必要步骤。

## 五阶段工作流定义

```
阶段1          阶段2          阶段3          阶段4          阶段5
创建提案项目 → 提案信息收集 → 提案初稿生成 → 审核及修改 → 正式发布
(create)      (collect)     (draft)       (review)     (publish)
```

### 阶段 1：创建提案项目 (create)
- **触发**：用户说"新建提案 {项目名称}"
- **操作**：
  1. 在 `workspace/projects/{项目名称}/` 下创建项目目录
  2. 创建 `workflow-status.md` 文件，记录项目元信息和阶段状态
  3. 创建 `collected-info.md` 空文件（等待下一阶段填充）
- **完成标志**：`workflow-status.md` 中 stage_1 标记为 ✅
- **输出**：向用户确认项目创建成功，展示工作流全景，提示说"开始采集"进入下一阶段

### 阶段 2：提案信息收集 (collect)
- **触发**：用户说"开始采集"或"信息收集"
- **前置检查**：阶段 1 必须已完成
- **操作**：按照 proposal-collector Skill 的流程引导用户逐步提供六大类信息
  - A. 业务需求与痛点
  - B. 技术规范要求
  - C. 行业规范要求
  - D. 处理效率要求
  - E. 机位/检测线布局
  - F. 基础设施条件
- **完成标志**：六大类信息中至少 A、B、D 三项已填写，`workflow-status.md` 中 stage_2 标记为 ✅
- **输出**：展示采集完成度，提示说"生成初稿"进入下一阶段

### 阶段 3：提案初稿生成 (draft)
- **触发**：用户说"生成初稿"或"写初稿"
- **前置检查**：阶段 2 必须已完成
- **操作**：
  1. 读取 `collected-info.md` 中的客户信息
  2. 读取 `workspace/references/` 下的知识库文件，匹配工艺流程和设备参数
  3. 执行需求分析，生成 `analysis-report.md`
  4. 基于分析结果，按照方案模板生成 `technical-proposal-draft.md`（注意文件名带 draft）
- **完成标志**：`technical-proposal-draft.md` 已生成，`workflow-status.md` 中 stage_3 标记为 ✅
- **输出**：通知用户初稿已生成，简要展示章节目录，提示说"审核方案"进入下一阶段

### 阶段 4：审核及修改 (review)
- **触发**：用户说"审核方案"或"审查方案"
- **前置检查**：阶段 3 必须已完成
- **操作**：
  1. 读取 `technical-proposal-draft.md`
  2. 执行五维度审查：
     - 完整性检查（章节是否齐全）
     - 参数一致性（与知识库对照）
     - 国标合规性（与标准库对照）
     - 通量合理性（计算是否自洽）
     - 客户需求匹配（与 collected-info.md 对照）
  3. 生成 `review-report.md`
  4. 如有 ❌ 项，自动修正并生成修改版 `technical-proposal-draft-v2.md`
  5. 如需用户确认的 ⚠️ 项，列出待确认清单
- **完成标志**：审查全部通过或用户确认接受，`workflow-status.md` 中 stage_4 标记为 ✅
- **输出**：展示审查结果摘要，提示说"发布方案"进入最终阶段

### 阶段 5：正式发布 (publish)
- **触发**：用户说"发布方案"或"正式发布"
- **前置检查**：阶段 4 必须已完成
- **操作**：
  1. 将最终审核通过的草稿重命名/复制为 `technical-proposal.md`（正式版本）
  2. 在文档头部添加正式信息：版本号 V1.0、日期、编制单位
  3. 更新 `workflow-status.md`，标记所有阶段完成
  4. 生成项目摘要 `project-summary.md`，包含：
     - 项目基本信息
     - 推荐方案概述
     - 关键设备清单
     - 通量和效率指标
- **完成标志**：`technical-proposal.md`（正式版）已生成
- **输出**：通知用户方案已正式发布，列出所有输出文件清单

## workflow-status.md 格式

当创建项目时，写入以下内容：

```markdown
# 项目工作流状态

## 项目信息
- 项目名称：{项目名称}
- 创建时间：{时间}
- 当前阶段：阶段 1 — 创建提案项目

## 阶段进度
| 阶段 | 名称 | 状态 | 完成时间 |
|------|------|------|---------|
| 1 | 创建提案项目 | ✅ 已完成 | {时间} |
| 2 | 提案信息收集 | ⬜ 待开始 | — |
| 3 | 提案初稿生成 | ⬜ 待开始 | — |
| 4 | 审核及修改 | ⬜ 待开始 | — |
| 5 | 正式发布 | ⬜ 待开始 | — |

## 操作日志
- {时间}：项目创建
```

每完成一个阶段，更新对应行的状态和时间，并追加操作日志。

## 状态查询

用户随时可以说"查看进度"或"提案状态"，此时：
1. 读取 `workflow-status.md`
2. 展示当前阶段、各阶段完成度
3. 提示下一步操作指令

## 阶段回退

用户可以说"回到采集阶段"或"重新生成初稿"，此时：
1. 将目标阶段及其之后的阶段状态重置为 ⬜
2. 更新操作日志
3. 从目标阶段重新开始

## 规则

### 严格规则（不可违反）
- **必须按顺序执行**：不可跳过阶段，每个阶段必须检查前置阶段已完成
- **必须使用知识库**：生成方案内容时，必须先读取 `workspace/references/` 下的文件，所有技术参数必须来自知识库，严禁编造
- **必须追踪状态**：每个操作都要更新 `workflow-status.md`

### 交互规则
- 每个阶段开始前，简要说明本阶段的目的和预期输出
- 每个阶段结束后，汇报完成情况并提示下一步指令
- 分步骤引导，不一次性输出大量内容
- 保持专业、简洁的中文沟通
- 信息采集阶段每次最多问 2-3 个问题

### 文件命名规则
- 信息采集：`collected-info.md`
- 需求分析：`analysis-report.md`
- 初稿：`technical-proposal-draft.md`（可有 v2、v3 等版本）
- 审查报告：`review-report.md`
- 正式版本：`technical-proposal.md`
- 工作流状态：`workflow-status.md`
- 项目摘要：`project-summary.md`

### 知识库引用规则
当进入阶段 3（初稿生成）时，必须按以下顺序读取知识库：
1. `workspace/references/product-specs.md` — 获取 SmartLabOS 系统参数
2. `workspace/references/process-quechers.md` 或 `process-inorganic.md` — 根据检测领域选择对应工艺流程
3. `workspace/references/unit-catalog.md` — 获取设备单元参数
4. `workspace/references/standards-library.md` — 获取国标要求
5. `workspace/references/proposal-template.md` — 获取文档模板结构

如果读取失败，告知用户哪个知识库文件缺失，并提示需要补充。
